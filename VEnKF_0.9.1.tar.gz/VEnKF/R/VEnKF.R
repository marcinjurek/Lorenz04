#' @docType package
#' @name VEnKF
#' @useDynLib VEnKF
#' @importFrom Rcpp sourceCpp
NULL